# fastscore.input: array-double
# fastscore.output: array-double

action <- function(dat){
	emit(dat)
}
