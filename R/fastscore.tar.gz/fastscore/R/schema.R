#' @include suite.model_manage.R

setClassUnion("characterOrList", c("character", "list"))

SchemaMetadata <- setRefClass("SchemaMetadata",
    fields=list(
        name="character"
    )
)

#' @title Schema
#' @description A class that represents a FastScore Schema
#' @export Schema
#' @field name schema name
#' @field source schema source code
#' @field model_manage the modelmanage it belongs to
Schema <- setRefClass("Schema",
    fields=list(
        name="character",
        source="characterOrList",
        model_manage="ModelManage"
        ),
    methods=list(
        update = function(model_manage=NULL){
            if(is.null(.self$model_manage) && is.null(model_manage)){
                stop(paste("FastScoreError: Schema", .self$name,
                "is not associated with Model Manage."))
            }
            if(is.null(.self$model_manage) || !is.null(model_manage)){
                .self$model_manage <- model_manage
            }
            .self$model_manage$save_schema(.self)
        }
    )
)
