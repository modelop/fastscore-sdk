library(testthat)
library(fastscore)

test_check("fastscore")
